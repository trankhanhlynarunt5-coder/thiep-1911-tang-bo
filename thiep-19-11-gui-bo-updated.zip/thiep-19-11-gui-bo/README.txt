THIỆP 19/11 GỬI BỐ

Trong thư mục này có một file chính: index.html.

CÁCH XEM THỬ
- Nhấp đúp vào index.html để mở bằng Chrome/Edge trên máy tính.
- Có thể gửi file HTML cho người khác, nhưng để quét QR bằng điện thoại và mở từ mọi nơi thì cần đưa file lên mạng.

CÁCH ĐƯA THIỆP LÊN MẠNG BẰNG NETLIFY DROP
1. Giải nén file ZIP này.
2. Mở https://app.netlify.com/drop.
3. Kéo cả thư mục thiep-19-11-gui-bo (thư mục có index.html bên trong) vào vùng tải lên. Nếu trang yêu cầu đăng nhập thì làm theo hướng dẫn trên Netlify.
4. Sau khi đăng tải, Netlify cấp một địa chỉ dạng https://ten-trang.netlify.app.
5. Mở đường link đó trên điện thoại hoặc cửa sổ ẩn danh để kiểm tra thiệp.
6. Dùng đường link công khai này để tạo mã QR. Không dùng đường dẫn file trên máy tính (ví dụ file:///C:/...).

LƯU Ý
- Trang thiệp chạy độc lập, không cần cài ứng dụng hay tải thư viện ngoài.
- Ai có đường link hoặc mã QR đều có thể mở trang thiệp. Không đưa thông tin riêng tư vào thiệp.
- Nếu muốn sửa lời chúc, mở index.html bằng Notepad hoặc VS Code, sửa phần chữ trong các mục lời nhắn rồi lưu lại. Sau đó tải lại thư mục lên Netlify để cập nhật.
